package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BmiRecordEntity
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.data.model.GymFacilityEntity
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.TrainerEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    fun getActiveUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Long): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET membershipTier = :tier, membershipExpiryDate = :expiry WHERE id = :userId")
    suspend fun updateMembership(userId: Long, tier: String, expiry: Long)
}

@Dao
interface MembershipPlanDao {
    @Query("SELECT * FROM membership_plans")
    fun getAllPlans(): Flow<List<MembershipPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlans(plans: List<MembershipPlanEntity>)

    @Query("SELECT * FROM membership_plans WHERE id = :planId LIMIT 1")
    suspend fun getPlanById(planId: String): MembershipPlanEntity?
}

@Dao
interface GymClassDao {
    @Query("SELECT * FROM gym_classes ORDER BY id ASC")
    fun getAllClasses(): Flow<List<GymClassEntity>>

    @Query("SELECT * FROM gym_classes WHERE category = :category")
    fun getClassesByCategory(category: String): Flow<List<GymClassEntity>>

    @Query("SELECT * FROM gym_classes WHERE dayOfWeek = :day")
    fun getClassesByDay(day: String): Flow<List<GymClassEntity>>

    @Query("SELECT * FROM gym_classes WHERE id = :id LIMIT 1")
    suspend fun getClassById(id: Long): GymClassEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<GymClassEntity>)

    @Query("UPDATE gym_classes SET bookedCount = bookedCount + 1 WHERE id = :id AND bookedCount < capacity")
    suspend fun incrementBooking(id: Long): Int

    @Query("UPDATE gym_classes SET bookedCount = MAX(0, bookedCount - 1) WHERE id = :id")
    suspend fun decrementBooking(id: Long)
}

@Dao
interface ClassBookingDao {
    @Query("SELECT * FROM class_bookings WHERE userId = :userId ORDER BY timestamp DESC")
    fun getBookingsForUser(userId: Long): Flow<List<ClassBookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: ClassBookingEntity): Long

    @Query("UPDATE class_bookings SET status = 'CANCELLED' WHERE id = :bookingId")
    suspend fun cancelBooking(bookingId: Long)

    @Query("SELECT * FROM class_bookings WHERE userId = :userId AND classId = :classId AND status = 'CONFIRMED' LIMIT 1")
    suspend fun findActiveBooking(userId: Long, classId: Long): ClassBookingEntity?
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE userId = :userId ORDER BY timestamp DESC")
    fun getPaymentsForUser(userId: Long): Flow<List<PaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long
}

@Dao
interface BmiRecordDao {
    @Query("SELECT * FROM bmi_records WHERE userId = :userId ORDER BY timestamp DESC")
    fun getBmiRecordsForUser(userId: Long): Flow<List<BmiRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBmiRecord(record: BmiRecordEntity): Long

    @Query("DELETE FROM bmi_records WHERE id = :id")
    suspend fun deleteBmiRecord(id: Long)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun getNotifications(userId: Long): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND isRead = 0")
    fun getUnreadCount(userId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllAsRead(userId: Long)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: Long)
}

@Dao
interface TrainerDao {
    @Query("SELECT * FROM trainers ORDER BY rating DESC")
    fun getAllTrainers(): Flow<List<TrainerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrainers(trainers: List<TrainerEntity>)
}

@Dao
interface FacilityDao {
    @Query("SELECT * FROM gym_facilities ORDER BY id ASC")
    fun getAllFacilities(): Flow<List<GymFacilityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFacilities(facilities: List<GymFacilityEntity>)
}
