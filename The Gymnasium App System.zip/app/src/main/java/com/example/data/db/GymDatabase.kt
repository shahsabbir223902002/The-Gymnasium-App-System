package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BmiRecordEntity
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.data.model.GymFacilityEntity
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.TrainerEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        MembershipPlanEntity::class,
        GymClassEntity::class,
        ClassBookingEntity::class,
        PaymentEntity::class,
        BmiRecordEntity::class,
        NotificationEntity::class,
        TrainerEntity::class,
        GymFacilityEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GymDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun membershipPlanDao(): MembershipPlanDao
    abstract fun gymClassDao(): GymClassDao
    abstract fun classBookingDao(): ClassBookingDao
    abstract fun paymentDao(): PaymentDao
    abstract fun bmiRecordDao(): BmiRecordDao
    abstract fun notificationDao(): NotificationDao
    abstract fun trainerDao(): TrainerDao
    abstract fun facilityDao(): FacilityDao

    companion object {
        @Volatile
        private var INSTANCE: GymDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): GymDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GymDatabase::class.java,
                    "gymnasium_database"
                )
                    .addCallback(GymDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class GymDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: GymDatabase) {
            // Default User
            val defaultUserId = db.userDao().insertUser(
                UserEntity(
                    username = "alex_fit",
                    fullName = "Alex Vance",
                    email = "alex.vance@gym.com",
                    phone = "+1 (555) 321-7890",
                    membershipTier = "PRO",
                    membershipExpiryDate = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000), // 30 days
                    fitnessGoal = "Hypertrophy & Core Conditioning",
                    avatarInitials = "AV"
                )
            )

            // Membership Plans
            val plans = listOf(
                MembershipPlanEntity(
                    id = "basic",
                    title = "Basic Fit Pass",
                    tagline = "Essential gym floor access for consistent workout routines",
                    price = 29.99,
                    durationMonths = 1,
                    isPopular = false,
                    badge = "STARTER",
                    perksList = "Access to Gym Cardio & Free Weights,Locker Room & Shower Access,1 Free Fitness Assessment,Complimentary Water Station"
                ),
                MembershipPlanEntity(
                    id = "pro",
                    title = "Pro Athlete",
                    tagline = "Full access with unlimited group fitness classes & sauna",
                    price = 59.99,
                    durationMonths = 1,
                    isPopular = true,
                    badge = "MOST POPULAR",
                    perksList = "All Basic Features,Unlimited Group Studio Classes (HIIT/Yoga/Boxing),Sauna & Steam Bath Recovery,1 Monthly 1-on-1 PT Consultation,Guest Pass (2 per month),Gym Mobile App Priority Booking"
                ),
                MembershipPlanEntity(
                    id = "elite",
                    title = "VIP Elite Club",
                    tagline = "Ultimate luxury fitness experience with dedicated coaching",
                    price = 99.99,
                    durationMonths = 1,
                    isPopular = false,
                    badge = "PREMIUM",
                    perksList = "All Pro Features,Unlimited Olympic Pool Access,Weekly Personal Trainer Session,Customized Nutrition & Macro Plan,Towel Service & VIP Lounge,Smoothie Bar 20% Discount"
                ),
                MembershipPlanEntity(
                    id = "annual",
                    title = "Annual Champion",
                    tagline = "Complete all-inclusive commitment for 12 months with 2 months free",
                    price = 499.99,
                    durationMonths = 12,
                    isPopular = false,
                    badge = "BEST VALUE",
                    perksList = "365-day Unlimited Access,Save 35% compared to monthly,Free Gym Swag Bag & Shaker,Unlimited Guest Privileges,Freeze Membership anytime up to 60 days"
                )
            )
            db.membershipPlanDao().insertPlans(plans)

            // Gym Classes
            val classes = listOf(
                GymClassEntity(
                    id = 1,
                    title = "Inferno HIIT Blast",
                    category = "HIIT",
                    trainerName = "Marcus Cole",
                    trainerRole = "CrossFit & High-Intensity Master",
                    dayOfWeek = "Mon",
                    timeSlot = "07:00 AM",
                    durationMinutes = 45,
                    caloriesBurn = 550,
                    intensity = "Intense",
                    capacity = 20,
                    bookedCount = 14,
                    roomLocation = "Studio A - Performance Deck",
                    description = "Fast-paced intervals using kettlebells, battle ropes, and plyometric drills to shred fat and boost cardiovascular power."
                ),
                GymClassEntity(
                    id = 2,
                    title = "Power Sculpt & Iron",
                    category = "Strength",
                    trainerName = "Elena Rostova",
                    trainerRole = "Olympic Weightlifting & Hypertrophy Coach",
                    dayOfWeek = "Mon",
                    timeSlot = "05:30 PM",
                    durationMinutes = 60,
                    caloriesBurn = 420,
                    intensity = "High",
                    capacity = 16,
                    bookedCount = 11,
                    roomLocation = "Heavy Iron Zone",
                    description = "Barbell squats, deadlifts, and compound strength mechanics designed to build lean functional muscle safely."
                ),
                GymClassEntity(
                    id = 3,
                    title = "Vinyasa Flow & Restore",
                    category = "Yoga",
                    trainerName = "Chloe Bennett",
                    trainerRole = "Registered Yoga Master (E-RYT 500)",
                    dayOfWeek = "Tue",
                    timeSlot = "08:30 AM",
                    durationMinutes = 50,
                    caloriesBurn = 260,
                    intensity = "Moderate",
                    capacity = 25,
                    bookedCount = 18,
                    roomLocation = "Zen Mind-Body Studio",
                    description = "Dynamic breathing sequences paired with deep hip openers and spine mobility for optimal athletic recovery."
                ),
                GymClassEntity(
                    id = 4,
                    title = "Turbo Velocity Spin",
                    category = "Spinning",
                    trainerName = "Devon Miller",
                    trainerRole = "Pro Cyclist & Rhythm Spin Specialist",
                    dayOfWeek = "Tue",
                    timeSlot = "06:00 PM",
                    durationMinutes = 45,
                    caloriesBurn = 620,
                    intensity = "Intense",
                    capacity = 24,
                    bookedCount = 21,
                    roomLocation = "Rhythm Cycle Arena",
                    description = "High-energy climbs, sprints, and rhythm drills set to heavy bass beats with real-time biometric telemetry."
                ),
                GymClassEntity(
                    id = 5,
                    title = "Strike Zone Boxing",
                    category = "Boxing",
                    trainerName = "Tyson 'Iron' Brooks",
                    trainerRole = "Golden Gloves Champion & Boxing Trainer",
                    dayOfWeek = "Wed",
                    timeSlot = "06:30 PM",
                    durationMinutes = 55,
                    caloriesBurn = 680,
                    intensity = "Intense",
                    capacity = 18,
                    bookedCount = 15,
                    roomLocation = "Combat Ring & Bag Pavilion",
                    description = "Heavy bag combinations, defensive footwork, and core conditioning in an authentic boxing gym format."
                ),
                GymClassEntity(
                    id = 6,
                    title = "Reformer Core Pilates",
                    category = "Pilates",
                    trainerName = "Sophia Lin",
                    trainerRole = "Classical Pilates & Posture Specialist",
                    dayOfWeek = "Thu",
                    timeSlot = "09:00 AM",
                    durationMinutes = 50,
                    caloriesBurn = 310,
                    intensity = "Moderate",
                    capacity = 12,
                    bookedCount = 9,
                    roomLocation = "Pilates Reformer Loft",
                    description = "Precise spring-resistance movements emphasizing deep abdominal activation, pelvic alignment, and posture."
                ),
                GymClassEntity(
                    id = 7,
                    title = "Spartan Kettlebell Circuit",
                    category = "HIIT",
                    trainerName = "Marcus Cole",
                    trainerRole = "CrossFit & High-Intensity Master",
                    dayOfWeek = "Fri",
                    timeSlot = "07:30 AM",
                    durationMinutes = 45,
                    caloriesBurn = 500,
                    intensity = "High",
                    capacity = 20,
                    bookedCount = 12,
                    roomLocation = "Studio A - Performance Deck",
                    description = "Explosive kettlebell snatches, clean and presses, and burpee intervals designed for full body endurance."
                ),
                GymClassEntity(
                    id = 8,
                    title = "Weekend Warrior BootCamp",
                    category = "Strength",
                    trainerName = "Elena Rostova",
                    trainerRole = "Olympic Weightlifting & Hypertrophy Coach",
                    dayOfWeek = "Sat",
                    timeSlot = "10:00 AM",
                    durationMinutes = 75,
                    caloriesBurn = 700,
                    intensity = "Extreme",
                    capacity = 30,
                    bookedCount = 23,
                    roomLocation = "Outdoor Turf & Functional Box",
                    description = "Sled pushes, farmer carries, tyre flips, and group battle relay rounds for the ultimate weekend burn."
                )
            )
            db.gymClassDao().insertClasses(classes)

            // Trainers
            val trainers = listOf(
                TrainerEntity(
                    id = 1,
                    name = "Marcus Cole",
                    specialty = "High Intensity Conditioning & Calisthenics",
                    experienceYears = 8,
                    rating = 4.9f,
                    reviewsCount = 142,
                    bio = "Former collegiate athlete with 8+ years coaching champions. Specializes in metabolic conditioning, rapid fat loss, and explosive functional movement.",
                    certifications = "NASM CPT, CrossFit Level 3, FMS Certified",
                    availability = "Mon - Fri: 6:00 AM - 2:00 PM"
                ),
                TrainerEntity(
                    id = 2,
                    name = "Elena Rostova",
                    specialty = "Hypertrophy, Powerlifting & Biomechanics",
                    experienceYears = 10,
                    rating = 5.0f,
                    reviewsCount = 198,
                    bio = "National competitive powerlifter and strength coach. Passionate about barbell mechanics, injury-prevention protocols, and sculpted physique development.",
                    certifications = "CSCS (NSCA), USA Weightlifting Level 2, Precision Nutrition L1",
                    availability = "Mon - Sat: 1:00 PM - 8:00 PM"
                ),
                TrainerEntity(
                    id = 3,
                    name = "Tyson 'Iron' Brooks",
                    specialty = "Boxing Technique, Agility & Core Conditioning",
                    experienceYears = 12,
                    rating = 4.8f,
                    reviewsCount = 115,
                    bio = "Golden Gloves Champion dedicated to teaching authentic boxing fundamentals, reaction speed, footwork, and mental fortitude.",
                    certifications = "USA Boxing Certified Coach, ACE Master Trainer",
                    availability = "Tue - Sun: 10:00 AM - 6:00 PM"
                ),
                TrainerEntity(
                    id = 4,
                    name = "Chloe Bennett",
                    specialty = "Mindful Mobility, Vinyasa Yoga & Breathwork",
                    experienceYears = 7,
                    rating = 4.9f,
                    reviewsCount = 89,
                    bio = "Bringing restorative balance to high-octane fitness. Chloe integrates yogic flow, kinetic stretching, and mindfulness for muscle longevity.",
                    certifications = "E-RYT 500 Yoga Alliance, Functional Range Conditioning (FRC)",
                    availability = "Mon - Fri: 7:00 AM - 1:00 PM"
                )
            )
            db.trainerDao().insertTrainers(trainers)

            // Facilities
            val facilities = listOf(
                GymFacilityEntity(
                    id = 1,
                    name = "Heavy Iron & Dumbbell Zone",
                    category = "Strength",
                    description = "Custom calibrated Eleiko Olympic lifting platforms, dumbbell racks up to 150 lbs, Rogue power cages, and cable towers.",
                    openingHours = "24/7 Access for Members",
                    equipmentCount = 45,
                    highlights = "Eleiko Bars, Rogue Monster Racks, Dumbbells 5-150 lbs, Olympic Benches"
                ),
                GymFacilityEntity(
                    id = 2,
                    name = "High-Performance Cardio Deck",
                    category = "Cardio",
                    description = "Matrix curved treadmills, Concept2 rowers, SkiErgs, Assault AirBikes, and stair climbers with interactive scenic touchscreens.",
                    openingHours = "24/7 Access for Members",
                    equipmentCount = 38,
                    highlights = "Heart Rate Telemetry, Curved Slat Treadmills, Concept2 Rowers & SkiErgs"
                ),
                GymFacilityEntity(
                    id = 3,
                    name = "Hydrothermal Sauna & Steam Bath",
                    category = "Recovery",
                    description = "Finnish dry cedar sauna and eucalyptus-infused herbal steam rooms engineered for deep muscular relaxation and toxin expulsion.",
                    openingHours = "6:00 AM - 11:00 PM Daily",
                    equipmentCount = 4,
                    highlights = "Finnish Cedar Wood, Eucalyptus Aromatherapy, Cold Plunge Showers"
                ),
                GymFacilityEntity(
                    id = 4,
                    name = "Olympic 25m Heated Lap Pool",
                    category = "Aquatics",
                    description = "Crystal clear temperature-regulated 6-lane lap pool with ultraviolet water purification and lane reservation.",
                    openingHours = "5:30 AM - 10:00 PM Daily",
                    equipmentCount = 6,
                    highlights = "Heated 80°F, UV Sanitized, Kickboards & Pull Buoys, Lifeguards on duty"
                ),
                GymFacilityEntity(
                    id = 5,
                    name = "Fuel Bar & Nutrition Lounge",
                    category = "Nutrition",
                    description = "Freshly blended whey & plant-based protein shakes, cold-pressed green juices, pre-workout shots, and healthy macro meal preps.",
                    openingHours = "7:00 AM - 9:00 PM Daily",
                    equipmentCount = 1,
                    highlights = "Grass-Fed Whey, Vegan Protein, BCAA Elixirs, Certified Nutritionist on-site"
                )
            )
            db.facilityDao().insertFacilities(facilities)

            // Sample Initial BMI Record
            db.bmiRecordDao().insertBmiRecord(
                BmiRecordEntity(
                    userId = defaultUserId,
                    heightCm = 178f,
                    weightKg = 74.5f,
                    bmi = 23.5f,
                    category = "Normal Weight",
                    recommendation = "Optimal body composition. Maintain consistent resistance training and 1.6-2.0g protein/kg of bodyweight."
                )
            )

            // Initial Welcome Notification
            db.notificationDao().insertNotification(
                NotificationEntity(
                    userId = defaultUserId,
                    title = "Welcome to Gymnasium System! 💪",
                    message = "Your Pro Athlete membership is active. Browse classes, track your BMI, or check out our sauna & Olympic pool!",
                    type = "MEMBERSHIP"
                )
            )

            // Initial active booking
            db.classBookingDao().insertBooking(
                ClassBookingEntity(
                    userId = defaultUserId,
                    classId = 1,
                    className = "Inferno HIIT Blast",
                    category = "HIIT",
                    trainerName = "Marcus Cole",
                    classDate = "Mon, Oct 5",
                    classTime = "07:00 AM",
                    status = "CONFIRMED"
                )
            )
        }
    }
}
