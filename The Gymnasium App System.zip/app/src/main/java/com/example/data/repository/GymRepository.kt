package com.example.data.repository

import com.example.data.db.GymDatabase
import com.example.data.model.BmiRecordEntity
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.data.model.GymFacilityEntity
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.TrainerEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class GymRepository(private val db: GymDatabase) {

    val activeUser: Flow<UserEntity?> = db.userDao().getActiveUser()
    val allPlans: Flow<List<MembershipPlanEntity>> = db.membershipPlanDao().getAllPlans()
    val allClasses: Flow<List<GymClassEntity>> = db.gymClassDao().getAllClasses()
    val allTrainers: Flow<List<TrainerEntity>> = db.trainerDao().getAllTrainers()
    val allFacilities: Flow<List<GymFacilityEntity>> = db.facilityDao().getAllFacilities()

    fun getBookingsForUser(userId: Long): Flow<List<ClassBookingEntity>> =
        db.classBookingDao().getBookingsForUser(userId)

    fun getPaymentsForUser(userId: Long): Flow<List<PaymentEntity>> =
        db.paymentDao().getPaymentsForUser(userId)

    fun getBmiRecords(userId: Long): Flow<List<BmiRecordEntity>> =
        db.bmiRecordDao().getBmiRecordsForUser(userId)

    fun getNotifications(userId: Long): Flow<List<NotificationEntity>> =
        db.notificationDao().getNotifications(userId)

    fun getUnreadNotificationsCount(userId: Long): Flow<Int> =
        db.notificationDao().getUnreadCount(userId)

    suspend fun registerUser(fullName: String, email: String, phone: String, goal: String): Long {
        val initials = fullName.split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .map { it.first().uppercaseChar() }
            .joinToString("")
            .ifEmpty { "GY" }

        val user = UserEntity(
            username = email.substringBefore("@"),
            fullName = fullName,
            email = email,
            phone = phone,
            membershipTier = "NONE",
            membershipExpiryDate = 0L,
            fitnessGoal = goal,
            avatarInitials = initials
        )
        val userId = db.userDao().insertUser(user)

        db.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Account Created! 🎉",
                message = "Welcome to Gymnasium System, $fullName. Choose a membership plan to unlock all classes!",
                type = "MEMBERSHIP"
            )
        )
        return userId
    }

    suspend fun loginUser(email: String): UserEntity? {
        return db.userDao().getUserByEmail(email)
    }

    suspend fun updateUser(user: UserEntity) {
        db.userDao().updateUser(user)
    }

    suspend fun bookClass(userId: Long, gymClass: GymClassEntity, dateStr: String): Result<Long> {
        val existing = db.classBookingDao().findActiveBooking(userId, gymClass.id)
        if (existing != null) {
            return Result.failure(Exception("You have already booked this class!"))
        }

        if (gymClass.bookedCount >= gymClass.capacity) {
            return Result.failure(Exception("Class is at full capacity!"))
        }

        val rowsUpdated = db.gymClassDao().incrementBooking(gymClass.id)
        if (rowsUpdated == 0) {
            return Result.failure(Exception("Could not reserve spot in class"))
        }

        val booking = ClassBookingEntity(
            userId = userId,
            classId = gymClass.id,
            className = gymClass.title,
            category = gymClass.category,
            trainerName = gymClass.trainerName,
            classDate = dateStr,
            classTime = gymClass.timeSlot,
            status = "CONFIRMED"
        )
        val bookingId = db.classBookingDao().insertBooking(booking)

        // Notification
        db.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Class Confirmed: ${gymClass.title} 🏋️‍♂️",
                message = "Your spot is reserved for $dateStr at ${gymClass.timeSlot} with Coach ${gymClass.trainerName} in ${gymClass.roomLocation}.",
                type = "BOOKING"
            )
        )

        return Result.success(bookingId)
    }

    suspend fun cancelBooking(bookingId: Long, classId: Long, userId: Long, className: String) {
        db.classBookingDao().cancelBooking(bookingId)
        db.gymClassDao().decrementBooking(classId)

        db.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Booking Cancelled",
                message = "Your booking for $className has been cancelled. Your spot was released.",
                type = "BOOKING"
            )
        )
    }

    suspend fun processPayment(
        userId: Long,
        amount: Double,
        itemDescription: String,
        paymentMethod: String,
        membershipTierToActivate: String?,
        durationMonths: Int
    ): PaymentEntity {
        val txId = "TXN-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val invoiceNo = "INV-" + dateFormat.format(Date()) + "-" + (1000..9999).random()

        val payment = PaymentEntity(
            userId = userId,
            transactionId = txId,
            invoiceNumber = invoiceNo,
            amount = amount,
            itemDescription = itemDescription,
            paymentMethod = paymentMethod,
            status = "SUCCESS",
            timestamp = System.currentTimeMillis()
        )
        val paymentId = db.paymentDao().insertPayment(payment)

        // If this payment was for a membership plan, activate or extend it
        if (!membershipTierToActivate.isNullOrBlank() && membershipTierToActivate != "NONE") {
            val user = db.userDao().getUserById(userId)
            val currentExpiry = user?.membershipExpiryDate ?: 0L
            val now = System.currentTimeMillis()
            val startFrom = if (currentExpiry > now) currentExpiry else now
            val addedDurationMs = durationMonths * 30L * 24 * 60 * 60 * 1000L
            val newExpiry = startFrom + addedDurationMs

            db.userDao().updateMembership(userId, membershipTierToActivate, newExpiry)

            db.notificationDao().insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Membership Activated! 👑",
                    message = "Your $membershipTierToActivate membership has been paid ($$amount via $paymentMethod) and activated.",
                    type = "MEMBERSHIP"
                )
            )
        } else {
            db.notificationDao().insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Payment Successful 💳",
                    message = "$$amount received for $itemDescription. Invoice #$invoiceNo generated.",
                    type = "PAYMENT"
                )
            )
        }

        return payment.copy(id = paymentId)
    }

    suspend fun saveBmiRecord(
        userId: Long,
        heightCm: Float,
        weightKg: Float,
        bmi: Float,
        category: String,
        recommendation: String
    ): Long {
        val id = db.bmiRecordDao().insertBmiRecord(
            BmiRecordEntity(
                userId = userId,
                heightCm = heightCm,
                weightKg = weightKg,
                bmi = bmi,
                category = category,
                recommendation = recommendation
            )
        )

        db.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "BMI Assessment Logged 📊",
                message = "New score: ${"%.1f".format(bmi)} ($category). Custom fitness recommendations updated.",
                type = "FITNESS"
            )
        )
        return id
    }

    suspend fun markAllNotificationsAsRead(userId: Long) {
        db.notificationDao().markAllAsRead(userId)
    }

    suspend fun deleteNotification(id: Long) {
        db.notificationDao().deleteNotification(id)
    }
}
