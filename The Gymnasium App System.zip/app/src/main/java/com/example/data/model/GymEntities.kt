package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val membershipTier: String = "NONE", // NONE, BASIC, PRO, VIP, ANNUAL
    val membershipExpiryDate: Long = 0L,
    val fitnessGoal: String = "Weight Loss & Strength",
    val avatarInitials: String = "GY"
)

@Entity(tableName = "membership_plans")
data class MembershipPlanEntity(
    @PrimaryKey val id: String,
    val title: String,
    val tagline: String,
    val price: Double,
    val durationMonths: Int,
    val isPopular: Boolean,
    val badge: String,
    val perksList: String // Comma separated perks
)

@Entity(tableName = "gym_classes")
data class GymClassEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val category: String, // HIIT, Strength, Yoga, Spinning, Boxing, Pilates
    val trainerName: String,
    val trainerRole: String,
    val dayOfWeek: String, // Mon, Tue, Wed, Thu, Fri, Sat, Sun
    val timeSlot: String,
    val durationMinutes: Int,
    val caloriesBurn: Int,
    val intensity: String, // Beginner, Moderate, High, Intense
    val capacity: Int,
    val bookedCount: Int,
    val roomLocation: String,
    val description: String
)

@Entity(tableName = "class_bookings")
data class ClassBookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val classId: Long,
    val className: String,
    val category: String,
    val trainerName: String,
    val classDate: String,
    val classTime: String,
    val status: String = "CONFIRMED", // CONFIRMED, CANCELLED
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val transactionId: String,
    val invoiceNumber: String,
    val amount: Double,
    val itemDescription: String,
    val paymentMethod: String, // CARD, UPI, WALLET
    val status: String = "SUCCESS",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bmi_records")
data class BmiRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val heightCm: Float,
    val weightKg: Float,
    val bmi: Float,
    val category: String,
    val recommendation: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val title: String,
    val message: String,
    val type: String, // BOOKING, PAYMENT, MEMBERSHIP, FITNESS
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "trainers")
data class TrainerEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val specialty: String,
    val experienceYears: Int,
    val rating: Float,
    val reviewsCount: Int,
    val bio: String,
    val certifications: String,
    val availability: String
)

@Entity(tableName = "gym_facilities")
data class GymFacilityEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val category: String,
    val description: String,
    val openingHours: String,
    val equipmentCount: Int,
    val highlights: String
)
