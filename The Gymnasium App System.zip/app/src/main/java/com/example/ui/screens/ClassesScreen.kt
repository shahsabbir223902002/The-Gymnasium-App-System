package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymRedAccent
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary

@Composable
fun ClassesScreen(
    classes: List<GymClassEntity>,
    bookings: List<ClassBookingEntity>,
    onBookClass: (GymClassEntity) -> Unit,
    onCancelBooking: (ClassBookingEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMainTab by remember { mutableIntStateOf(0) } // 0: Browse Schedule, 1: My Bookings
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedDay by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    val categories = listOf("All", "HIIT", "Strength", "Yoga", "Spinning", "Boxing", "Pilates")
    val days = listOf("All", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    val filteredClasses = classes.filter { item ->
        val matchesCat = selectedCategory == "All" || item.category.equals(selectedCategory, ignoreCase = true)
        val matchesDay = selectedDay == "All" || item.dayOfWeek.equals(selectedDay, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.trainerName.contains(searchQuery, ignoreCase = true) ||
                item.category.contains(searchQuery, ignoreCase = true)
        matchesCat && matchesDay && matchesSearch
    }

    val activeBookings = bookings.filter { it.status == "CONFIRMED" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GymDarkBackground)
    ) {
        // Tab Selector (Schedule vs My Bookings)
        TabRow(
            selectedTabIndex = selectedMainTab,
            containerColor = GymDarkSurface,
            contentColor = GymOrangePrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedMainTab]),
                    color = GymOrangePrimary
                )
            }
        ) {
            Tab(
                selected = selectedMainTab == 0,
                onClick = { selectedMainTab = 0 },
                text = {
                    Text(
                        "Class Schedule (${classes.size})",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedMainTab == 0) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
            Tab(
                selected = selectedMainTab == 1,
                onClick = { selectedMainTab = 1 },
                text = {
                    Text(
                        "My Bookings (${activeBookings.size})",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedMainTab == 1) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
        }

        if (selectedMainTab == 0) {
            // Filter & Search Controls
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search class, coach, or workout...", color = GymTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = GymOrangePrimary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = GymTextSecondary,
                                modifier = Modifier.clickable { searchQuery = "" }
                            )
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GymOrangePrimary,
                        unfocusedBorderColor = GymBorder,
                        focusedTextColor = GymTextPrimary,
                        unfocusedTextColor = GymTextPrimary,
                        focusedContainerColor = GymDarkCard,
                        unfocusedContainerColor = GymDarkCard
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("class_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Days Filter
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(days) { day ->
                        val isSelected = selectedDay == day
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) GymOrangePrimary else GymDarkCard)
                                .border(1.dp, if (isSelected) GymOrangePrimary else GymBorder, RoundedCornerShape(8.dp))
                                .clickable { selectedDay = day }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = day,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else GymTextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Categories Filter
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) GymOrangePrimary.copy(alpha = 0.2f) else GymDarkCard)
                                .border(
                                    1.dp,
                                    if (isSelected) GymOrangePrimary else GymBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) GymOrangePrimary else GymTextSecondary
                            )
                        }
                    }
                }
            }

            // Class Cards List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                if (filteredClasses.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No classes match your filter criteria",
                                color = GymTextSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    items(filteredClasses, key = { it.id }) { gymClass ->
                        val isAlreadyBooked = bookings.any { it.classId == gymClass.id && it.status == "CONFIRMED" }
                        FullClassCard(
                            gymClass = gymClass,
                            isAlreadyBooked = isAlreadyBooked,
                            onBookClick = { onBookClass(gymClass) }
                        )
                    }
                }
            }
        } else {
            // My Bookings Tab
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                if (activeBookings.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = GymTextSecondary.copy(alpha = 0.5f),
                                    modifier = Modifier.size(54.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "No upcoming class bookings",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymTextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Browse the schedule and reserve your workout spots!",
                                    fontSize = 12.sp,
                                    color = GymTextSecondary
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { selectedMainTab = 0 },
                                    colors = ButtonDefaults.buttonColors(containerColor = GymOrangePrimary)
                                ) {
                                    Text("Explore Class Schedule")
                                }
                            }
                        }
                    }
                } else {
                    items(activeBookings, key = { it.id }) { booking ->
                        BookingItemCard(
                            booking = booking,
                            onCancel = { onCancelBooking(booking) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FullClassCard(
    gymClass: GymClassEntity,
    isAlreadyBooked: Boolean,
    onBookClick: () -> Unit
) {
    val spotsLeft = (gymClass.capacity - gymClass.bookedCount).coerceAtLeast(0)
    val progress = (gymClass.bookedCount.toFloat() / gymClass.capacity.toFloat()).coerceIn(0f, 1f)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GymDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isAlreadyBooked) GymNeonAccent.copy(alpha = 0.5f) else GymBorder
            )
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("class_card_${gymClass.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Category & Day Tag Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(GymOrangePrimary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = gymClass.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymOrangePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${gymClass.dayOfWeek} • ${gymClass.timeSlot}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymTextPrimary
                    )
                }

                if (isAlreadyBooked) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(GymNeonAccent.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = GymNeonAccent,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "BOOKED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GymNeonAccent
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = gymClass.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = GymTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = gymClass.description,
                fontSize = 12.sp,
                color = GymTextSecondary,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Metadata Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ClassMiniInfo(Icons.Default.AccessTime, "${gymClass.durationMinutes}m")
                ClassMiniInfo(Icons.Default.LocalFireDepartment, "${gymClass.caloriesBurn} kcal", GymOrangePrimary)
                ClassMiniInfo(Icons.Default.FitnessCenter, gymClass.intensity, GymNeonAccent)
                ClassMiniInfo(Icons.Default.LocationOn, gymClass.roomLocation.substringBefore("-").trim())
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Coach & Capacity Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = GymOrangePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = gymClass.trainerName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GymTextPrimary
                    )
                }

                Text(
                    text = "$spotsLeft spots left",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (spotsLeft <= 3) GymOrangePrimary else GymNeonAccent
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (spotsLeft <= 3) GymOrangePrimary else GymNeonAccent,
                trackColor = GymDarkSurfaceElevated
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onBookClick,
                enabled = spotsLeft > 0 && !isAlreadyBooked,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GymOrangePrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("book_button_${gymClass.id}")
            ) {
                Text(
                    text = when {
                        isAlreadyBooked -> "Reserved (You're In)"
                        spotsLeft <= 0 -> "Class Full"
                        else -> "Book Spot (${gymClass.timeSlot})"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ClassMiniInfo(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    tint: Color = GymTextSecondary
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(GymDarkSurfaceElevated)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text, fontSize = 10.sp, color = GymTextSecondary)
    }
}

@Composable
fun BookingItemCard(
    booking: ClassBookingEntity,
    onCancel: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GymDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymNeonAccent.copy(alpha = 0.3f))),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(GymNeonAccent.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CONFIRMED RESERVATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = GymNeonAccent
                    )
                }

                Text(
                    text = "${booking.classDate} • ${booking.classTime}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = GymTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = booking.className,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = GymTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Coach: ${booking.trainerName} • Category: ${booking.category}",
                fontSize = 12.sp,
                color = GymTextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = GymRedAccent),
                border = ButtonDefaults.outlinedButtonBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymRedAccent.copy(alpha = 0.5f))),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text("Cancel Reservation", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
