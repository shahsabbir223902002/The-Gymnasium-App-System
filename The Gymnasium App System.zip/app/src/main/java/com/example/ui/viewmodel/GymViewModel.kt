package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.GymDatabase
import com.example.data.model.BmiRecordEntity
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.data.model.GymFacilityEntity
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.TrainerEntity
import com.example.data.model.UserEntity
import com.example.data.repository.GymRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GymViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GymRepository

    init {
        val db = GymDatabase.getDatabase(application, viewModelScope)
        repository = GymRepository(db)
    }

    val currentUser: StateFlow<UserEntity?> = repository.activeUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allPlans: StateFlow<List<MembershipPlanEntity>> = repository.allPlans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClasses: StateFlow<List<GymClassEntity>> = repository.allClasses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrainers: StateFlow<List<TrainerEntity>> = repository.allTrainers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFacilities: StateFlow<List<GymFacilityEntity>> = repository.allFacilities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userBookings: StateFlow<List<ClassBookingEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getBookingsForUser(user.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userPayments: StateFlow<List<PaymentEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getPaymentsForUser(user.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userBmiRecords: StateFlow<List<BmiRecordEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getBmiRecords(user.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userNotifications: StateFlow<List<NotificationEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getNotifications(user.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val unreadNotificationsCount: StateFlow<Int> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getUnreadNotificationsCount(user.id) else flowOf(0)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Interactive Dialogs & Navigation State
    private val _selectedClassForBooking = MutableStateFlow<GymClassEntity?>(null)
    val selectedClassForBooking: StateFlow<GymClassEntity?> = _selectedClassForBooking.asStateFlow()

    private val _selectedPlanForPayment = MutableStateFlow<MembershipPlanEntity?>(null)
    val selectedPlanForPayment: StateFlow<MembershipPlanEntity?> = _selectedPlanForPayment.asStateFlow()

    private val _latestPaymentSuccess = MutableStateFlow<PaymentEntity?>(null)
    val latestPaymentSuccess: StateFlow<PaymentEntity?> = _latestPaymentSuccess.asStateFlow()

    private val _showAuthDialog = MutableStateFlow(false)
    val showAuthDialog: StateFlow<Boolean> = _showAuthDialog.asStateFlow()

    private val _showNotificationDialog = MutableStateFlow(false)
    val showNotificationDialog: StateFlow<Boolean> = _showNotificationDialog.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Interactive BMI Calculator State
    private val _bmiHeightCm = MutableStateFlow(175f)
    val bmiHeightCm: StateFlow<Float> = _bmiHeightCm.asStateFlow()

    private val _bmiWeightKg = MutableStateFlow(72f)
    val bmiWeightKg: StateFlow<Float> = _bmiWeightKg.asStateFlow()

    private val _bmiGender = MutableStateFlow("Male")
    val bmiGender: StateFlow<String> = _bmiGender.asStateFlow()

    private val _bmiAge = MutableStateFlow(27)
    val bmiAge: StateFlow<Int> = _bmiAge.asStateFlow()

    fun setHeight(height: Float) {
        _bmiHeightCm.value = height
    }

    fun setWeight(weight: Float) {
        _bmiWeightKg.value = weight
    }

    fun setGender(gender: String) {
        _bmiGender.value = gender
    }

    fun setAge(age: Int) {
        _bmiAge.value = age
    }

    fun selectClassForBooking(classEntity: GymClassEntity?) {
        _selectedClassForBooking.value = classEntity
    }

    fun selectPlanForPayment(plan: MembershipPlanEntity?) {
        _selectedPlanForPayment.value = plan
    }

    fun dismissPaymentSuccess() {
        _latestPaymentSuccess.value = null
    }

    fun setShowAuthDialog(show: Boolean) {
        _showAuthDialog.value = show
    }

    fun setShowNotificationDialog(show: Boolean) {
        _showNotificationDialog.value = show
        if (show) {
            markNotificationsRead()
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun bookClass(gymClass: GymClassEntity, dateStr: String) {
        val user = currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            _snackbarMessage.value = "Please log in to book classes"
            return
        }

        viewModelScope.launch {
            val result = repository.bookClass(user.id, gymClass, dateStr)
            if (result.isSuccess) {
                _selectedClassForBooking.value = null
                _snackbarMessage.value = "Class booked successfully! Spot reserved."
            } else {
                _snackbarMessage.value = result.exceptionOrNull()?.message ?: "Booking failed"
            }
        }
    }

    fun cancelBooking(booking: ClassBookingEntity) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.cancelBooking(booking.id, booking.classId, user.id, booking.className)
            _snackbarMessage.value = "Booking for ${booking.className} cancelled"
        }
    }

    fun executePlanPayment(plan: MembershipPlanEntity, paymentMethod: String) {
        val user = currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            _snackbarMessage.value = "Please sign in to proceed with payment"
            return
        }

        viewModelScope.launch {
            val payment = repository.processPayment(
                userId = user.id,
                amount = plan.price,
                itemDescription = "${plan.title} (${plan.durationMonths} Mo)",
                paymentMethod = paymentMethod,
                membershipTierToActivate = plan.id.uppercase(),
                durationMonths = plan.durationMonths
            )
            _selectedPlanForPayment.value = null
            _latestPaymentSuccess.value = payment
            _snackbarMessage.value = "Payment confirmed! Membership activated."
        }
    }

    fun saveCurrentBmiCalculation(category: String, recommendation: String) {
        val user = currentUser.value
        val height = _bmiHeightCm.value
        val weight = _bmiWeightKg.value
        val heightM = height / 100f
        val bmiVal = weight / (heightM * heightM)

        if (user == null) {
            _snackbarMessage.value = "Please sign in to save your BMI record"
            return
        }

        viewModelScope.launch {
            repository.saveBmiRecord(
                userId = user.id,
                heightCm = height,
                weightKg = weight,
                bmi = bmiVal,
                category = category,
                recommendation = recommendation
            )
            _snackbarMessage.value = "BMI Record saved to your fitness profile!"
        }
    }

    fun markNotificationsRead() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.markAllNotificationsAsRead(user.id)
        }
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            repository.deleteNotification(id)
        }
    }

    fun register(fullName: String, email: String, phone: String, goal: String) {
        if (fullName.isBlank() || email.isBlank()) {
            _snackbarMessage.value = "Please fill in your name and email"
            return
        }
        viewModelScope.launch {
            val id = repository.registerUser(fullName, email, phone, goal)
            _showAuthDialog.value = false
            _snackbarMessage.value = "Welcome, $fullName! Your gym account is active."
        }
    }

    fun login(email: String) {
        if (email.isBlank()) {
            _snackbarMessage.value = "Please enter your email"
            return
        }
        viewModelScope.launch {
            val user = repository.loginUser(email)
            if (user != null) {
                // Set active user
                repository.updateUser(user)
                _showAuthDialog.value = false
                _snackbarMessage.value = "Welcome back, ${user.fullName}!"
            } else {
                // If not found, create instant account
                val name = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                repository.registerUser(name, email, "+1 (555) 019-2834", "General Fitness")
                _showAuthDialog.value = false
                _snackbarMessage.value = "Account created & signed in!"
            }
        }
    }

    fun updateProfile(fullName: String, phone: String, goal: String) {
        val user = currentUser.value ?: return
        val initials = fullName.split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .map { it.first().uppercaseChar() }
            .joinToString("")
            .ifEmpty { "GY" }

        val updated = user.copy(
            fullName = fullName,
            phone = phone,
            fitnessGoal = goal,
            avatarInitials = initials
        )
        viewModelScope.launch {
            repository.updateUser(updated)
            _snackbarMessage.value = "Profile updated successfully!"
        }
    }
}
