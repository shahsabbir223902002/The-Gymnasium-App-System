package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.UserEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymGold
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary

@Composable
fun ProfileAuthDialog(
    user: UserEntity?,
    onDismiss: () -> Unit,
    onLogin: (email: String) -> Unit,
    onRegister: (name: String, email: String, phone: String, goal: String) -> Unit,
    onUpdateProfile: (name: String, phone: String, goal: String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Sign In / Profile, 1: Register

    // Form inputs
    var loginEmail by remember { mutableStateOf("alex.vance@gym.com") }
    var regName by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("+1 (555) ") }
    var regGoal by remember { mutableStateOf("Strength & Muscle Building") }

    // Edit Profile inputs
    var editName by remember { mutableStateOf(user?.fullName ?: "") }
    var editPhone by remember { mutableStateOf(user?.phone ?: "") }
    var editGoal by remember { mutableStateOf(user?.fitnessGoal ?: "General Fitness") }
    var isEditing by remember { mutableStateOf(false) }

    val goals = listOf(
        "Strength & Muscle Building",
        "Fat Loss & Conditioning",
        "Athletic Agility & Speed",
        "Flexibility & Mindful Health"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = GymDarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("profile_auth_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (user != null) "Member Profile" else "Gym Access",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = GymTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (user != null) {
                    // Profile View
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(GymDarkSurfaceElevated)
                                .border(2.dp, GymOrangePrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user.avatarInitials,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = GymOrangePrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = user.fullName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                        Text(
                            text = user.email,
                            fontSize = 12.sp,
                            color = GymTextSecondary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Membership Tier Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    if (user.membershipTier != "NONE") GymOrangePrimary.copy(alpha = 0.2f)
                                    else GymDarkCard
                                )
                                .border(
                                    1.dp,
                                    if (user.membershipTier != "NONE") GymOrangePrimary else GymBorder,
                                    RoundedCornerShape(20.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (user.membershipTier != "NONE") GymGold else GymTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (user.membershipTier != "NONE") "${user.membershipTier} PASS - ACTIVE" else "NO ACTIVE PASS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (user.membershipTier != "NONE") GymOrangePrimary else GymTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (!isEditing) {
                        // Display Information
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(GymDarkCard)
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Phone, null, tint = GymOrangePrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Phone: ${user.phone.ifEmpty { "Not set" }}", fontSize = 13.sp, color = GymTextPrimary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FitnessCenter, null, tint = GymOrangePrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Goal: ${user.fitnessGoal}", fontSize = 13.sp, color = GymTextPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { isEditing = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GymDarkSurfaceElevated,
                                    contentColor = GymTextPrimary
                                )
                            ) {
                                Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Edit Profile", fontSize = 13.sp)
                            }
                            Button(
                                onClick = { onLogin("alex.vance@gym.com") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GymOrangePrimary,
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Switch User", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // Edit Form
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Full Name", color = GymTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("Phone Number", color = GymTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editGoal,
                            onValueChange = { editGoal = it },
                            label = { Text("Fitness Goal", color = GymTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { isEditing = false }, modifier = Modifier.weight(1f)) {
                                Text("Cancel", color = GymTextSecondary)
                            }
                            Button(
                                onClick = {
                                    onUpdateProfile(editName, editPhone, editGoal)
                                    isEditing = false
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GymOrangePrimary)
                            ) {
                                Text("Save", color = Color.White)
                            }
                        }
                    }
                } else {
                    // Auth Tabs (Login / Register)
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = GymDarkCard,
                        contentColor = GymOrangePrimary,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = GymOrangePrimary
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Sign In", fontWeight = FontWeight.Bold, color = if (selectedTab == 0) GymOrangePrimary else GymTextSecondary) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Register", fontWeight = FontWeight.Bold, color = if (selectedTab == 1) GymOrangePrimary else GymTextSecondary) }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (selectedTab == 0) {
                        // Sign In Tab
                        OutlinedTextField(
                            value = loginEmail,
                            onValueChange = { loginEmail = it },
                            label = { Text("Gym Member Email", color = GymTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Email, null, tint = GymOrangePrimary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("login_email_input")
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onLogin(loginEmail) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("login_submit_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GymOrangePrimary)
                        ) {
                            Text("Sign In to Gym Account", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Register Tab
                        OutlinedTextField(
                            value = regName,
                            onValueChange = { regName = it },
                            label = { Text("Full Name", color = GymTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Person, null, tint = GymOrangePrimary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("register_name_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = regEmail,
                            onValueChange = { regEmail = it },
                            label = { Text("Email Address", color = GymTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Email, null, tint = GymOrangePrimary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("register_email_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = regPhone,
                            onValueChange = { regPhone = it },
                            label = { Text("Phone Number", color = GymTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Phone, null, tint = GymOrangePrimary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Select Primary Goal", fontSize = 12.sp, color = GymTextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            goals.forEach { goal ->
                                val isSelected = regGoal == goal
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) GymOrangePrimary.copy(alpha = 0.2f) else GymDarkCard)
                                        .border(
                                            1.dp,
                                            if (isSelected) GymOrangePrimary else GymBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { regGoal = goal }
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = goal,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) GymOrangePrimary else GymTextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onRegister(regName, regEmail, regPhone, regGoal) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("register_submit_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GymOrangePrimary)
                        ) {
                            Text("Create Member Account", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
