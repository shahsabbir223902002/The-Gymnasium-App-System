package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.MembershipPlanEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PaymentCheckoutDialog(
    plan: MembershipPlanEntity,
    onDismiss: () -> Unit,
    onPaymentSuccess: (paymentMethod: String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("CARD") } // CARD, UPI, WALLET
    var cardNumber by remember { mutableStateOf("4532 8920 1849 9021") }
    var cardExpiry by remember { mutableStateOf("08/28") }
    var cardCvv by remember { mutableStateOf("883") }
    var upiId by remember { mutableStateOf("athlete@okgym") }
    var isProcessing by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = GymDarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("payment_checkout_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Secure Checkout",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = GymTextPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = GymNeonAccent,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "256-Bit Encrypted Payment",
                                fontSize = 11.sp,
                                color = GymNeonAccent
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isProcessing,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = GymTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Plan Overview Box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GymDarkCard)
                        .border(1.dp, GymBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = plan.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = GymTextPrimary
                            )
                            Text(
                                text = "${plan.durationMonths} Month Duration",
                                fontSize = 12.sp,
                                color = GymTextSecondary
                            )
                        }
                        Text(
                            text = "$${"%.2f".format(plan.price)}",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = GymOrangePrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Method Selector
                Text(
                    text = "Select Payment Method",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = GymTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentMethodTab(
                        title = "Card",
                        icon = Icons.Default.CreditCard,
                        isSelected = selectedMethod == "CARD",
                        onClick = { selectedMethod = "CARD" },
                        modifier = Modifier.weight(1f)
                    )
                    PaymentMethodTab(
                        title = "UPI / QR",
                        icon = Icons.Default.QrCode,
                        isSelected = selectedMethod == "UPI",
                        onClick = { selectedMethod = "UPI" },
                        modifier = Modifier.weight(1f)
                    )
                    PaymentMethodTab(
                        title = "Wallet",
                        icon = Icons.Default.AccountBalanceWallet,
                        isSelected = selectedMethod == "WALLET",
                        onClick = { selectedMethod = "WALLET" },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Method Specific Fields
                when (selectedMethod) {
                    "CARD" -> {
                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { cardNumber = it },
                            label = { Text("Card Number", color = GymTextSecondary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                unfocusedBorderColor = GymBorder,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary,
                                focusedContainerColor = GymDarkCard,
                                unfocusedContainerColor = GymDarkCard
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_number_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = cardExpiry,
                                onValueChange = { cardExpiry = it },
                                label = { Text("MM/YY", color = GymTextSecondary) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GymOrangePrimary,
                                    unfocusedBorderColor = GymBorder,
                                    focusedTextColor = GymTextPrimary,
                                    unfocusedTextColor = GymTextPrimary,
                                    focusedContainerColor = GymDarkCard,
                                    unfocusedContainerColor = GymDarkCard
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("card_expiry_input")
                            )
                            OutlinedTextField(
                                value = cardCvv,
                                onValueChange = { cardCvv = it },
                                label = { Text("CVV", color = GymTextSecondary) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GymOrangePrimary,
                                    unfocusedBorderColor = GymBorder,
                                    focusedTextColor = GymTextPrimary,
                                    unfocusedTextColor = GymTextPrimary,
                                    focusedContainerColor = GymDarkCard,
                                    unfocusedContainerColor = GymDarkCard
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("card_cvv_input")
                            )
                        }
                    }

                    "UPI" -> {
                        OutlinedTextField(
                            value = upiId,
                            onValueChange = { upiId = it },
                            label = { Text("UPI ID (e.g. yourname@okaxis)", color = GymTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GymOrangePrimary,
                                unfocusedBorderColor = GymBorder,
                                focusedTextColor = GymTextPrimary,
                                unfocusedTextColor = GymTextPrimary,
                                focusedContainerColor = GymDarkCard,
                                unfocusedContainerColor = GymDarkCard
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("upi_id_input")
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Supports Google Pay, PhonePe, Paytm, and BHIM",
                            fontSize = 11.sp,
                            color = GymTextSecondary
                        )
                    }

                    "WALLET" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(GymDarkCard)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "1-Tap Digital Wallet: Instant checkout via linked Google Wallet / Gym Credits",
                                fontSize = 12.sp,
                                color = GymTextSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Price Summary
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GymDarkSurfaceElevated, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Subtotal", fontSize = 12.sp, color = GymTextSecondary)
                        Text("$${"%.2f".format(plan.price)}", fontSize = 12.sp, color = GymTextPrimary)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Club Processing Fee", fontSize = 12.sp, color = GymTextSecondary)
                        Text("$0.00 (Waived)", fontSize = 12.sp, color = GymNeonAccent)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Due Today", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = GymTextPrimary)
                        Text(
                            "$${"%.2f".format(plan.price)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = GymOrangePrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Pay Button
                Button(
                    onClick = {
                        isProcessing = true
                        coroutineScope.launch {
                            delay(1200) // Realistic secure checkout simulation
                            isProcessing = false
                            onPaymentSuccess(selectedMethod)
                        }
                    },
                    enabled = !isProcessing,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GymOrangePrimary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pay_now_button")
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Processing Payment...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Pay $${"%.2f".format(plan.price)} & Join",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentMethodTab(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) GymOrangePrimary.copy(alpha = 0.2f) else GymDarkCard)
            .border(
                width = 1.dp,
                color = if (isSelected) GymOrangePrimary else GymBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) GymOrangePrimary else GymTextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) GymOrangePrimary else GymTextSecondary
            )
        }
    }
}
