package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fitness Dark & Orange Brand Palette
val GymOrangePrimary = Color(0xFFFF6D00)
val GymOrangeDark = Color(0xFFE65100)
val GymOrangeLight = Color(0xFFFF9E40)
val GymAmberSecondary = Color(0xFFFFB300)
val GymNeonAccent = Color(0xFF00E676)
val GymRedAccent = Color(0xFFFF3D00)

val GymDarkBackground = Color(0xFF0F1014)
val GymDarkSurface = Color(0xFF181A20)
val GymDarkSurfaceElevated = Color(0xFF22252E)
val GymDarkSurfaceVariant = Color(0xFF2B2F3B)
val GymDarkCard = Color(0xFF1D2029)
val GymBorder = Color(0xFF2E3342)

val GymTextPrimary = Color(0xFFF6F7F9)
val GymTextSecondary = Color(0xFFA2A7B5)
val GymTextMuted = Color(0xFF6B7280)

val GymGold = Color(0xFFFFD700)
val GymSilver = Color(0xFFCFD8DC)
val GymBronze = Color(0xFFCD7F32)
