package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ClassBookingEntity
import com.example.data.model.GymClassEntity
import com.example.data.model.GymFacilityEntity
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.UserEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymGold
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangeDark
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary

data class ProgramHighlight(
    val title: String,
    val subtitle: String,
    val intensity: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val accentColor: Color
)

@Composable
fun HomeScreen(
    user: UserEntity?,
    classes: List<GymClassEntity>,
    plans: List<MembershipPlanEntity>,
    facilities: List<GymFacilityEntity>,
    userBookings: List<ClassBookingEntity>,
    onNavigateToClasses: () -> Unit,
    onNavigateToPlans: () -> Unit,
    onNavigateToBmi: () -> Unit,
    onNavigateToFacilities: () -> Unit,
    onBookClassClick: (GymClassEntity) -> Unit,
    onUpgradePlanClick: (MembershipPlanEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val programs = listOf(
        ProgramHighlight("Power Hypertrophy", "Iron & Olympic lifting", "Intense", Icons.Default.FitnessCenter, GymOrangePrimary),
        ProgramHighlight("Inferno Shred", "High intensity metabolic intervals", "Extreme", Icons.Default.LocalFireDepartment, GymNeonAccent),
        ProgramHighlight("Strike Combat", "Heavy bag boxing & footwork", "High", Icons.Default.SportsGymnastics, GymGold),
        ProgramHighlight("Aquatic Endurance", "Olympic lap swimming & drills", "Moderate", Icons.Default.Pool, Color(0xFF00B0FF))
    )

    val activeBooking = userBookings.firstOrNull { it.status == "CONFIRMED" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GymDarkBackground),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Banner Section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .testTag("home_hero_banner")
            ) {
                // Background Gym Photo
                Image(
                    painter = painterResource(id = R.drawable.bg_gym_hero),
                    contentDescription = "Gym Facility Interior",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark Gradient Scrim with Orange Glow
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.35f),
                                    Color.Black.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                // Hero Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(GymOrangePrimary)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "LEVEL UP YOUR FITNESS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        }

                        if (user != null && user.membershipTier != "NONE") {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = GymGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${user.membershipTier} MEMBER",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Column {
                        Text(
                            text = if (user != null) "Welcome back,\n${user.fullName}!" else "Welcome to\nGymnasium Club",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                lineHeight = 30.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "State-of-the-art facilities • Elite certified coaching • 24/7 Access",
                            fontSize = 12.sp,
                            color = GymTextSecondary
                        )
                    }
                }
            }
        }

        // Quick Action Shortcuts
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    title = "Classes",
                    subtitle = "Book Spot",
                    icon = Icons.Default.CalendarMonth,
                    color = GymOrangePrimary,
                    onClick = onNavigateToClasses,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_action_classes"
                )
                QuickActionItem(
                    title = "Plans",
                    subtitle = "Join / Pay",
                    icon = Icons.Default.CardMembership,
                    color = GymGold,
                    onClick = onNavigateToPlans,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_action_plans"
                )
                QuickActionItem(
                    title = "BMI Meter",
                    subtitle = "Calculate",
                    icon = Icons.Default.Calculate,
                    color = GymNeonAccent,
                    onClick = onNavigateToBmi,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_action_bmi"
                )
                QuickActionItem(
                    title = "Club",
                    subtitle = "Facilities",
                    icon = Icons.Default.MeetingRoom,
                    color = Color(0xFF00B0FF),
                    onClick = onNavigateToFacilities,
                    modifier = Modifier.weight(1f),
                    testTag = "quick_action_facilities"
                )
            }
        }

        // Active Booking or Upgrade CTA Card
        item {
            if (activeBooking != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { onNavigateToClasses() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymOrangePrimary.copy(alpha = 0.5f)))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(GymOrangePrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = GymOrangePrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "UPCOMING RESERVED CLASS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymOrangePrimary
                                )
                                Text(
                                    text = activeBooking.className,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymTextPrimary
                                )
                                Text(
                                    text = "${activeBooking.classDate} • ${activeBooking.classTime} with ${activeBooking.trainerName}",
                                    fontSize = 12.sp,
                                    color = GymTextSecondary
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = GymTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            } else {
                // Promotional Membership Callout
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { onNavigateToPlans() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GymOrangePrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = GymOrangePrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "JOIN PRO ATHLETE PLAN",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = GymOrangePrimary
                                )
                                Text(
                                    text = "Unlimited classes & sauna from $59.99/mo",
                                    fontSize = 13.sp,
                                    color = GymTextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(GymOrangePrimary)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "EXPLORE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Section: Signature Gym Programs & Services
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "GYM PROGRAMS & SERVICES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Text(
                            text = "Engineered For Peak Results",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                    }
                    Text(
                        text = "View All",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymOrangePrimary,
                        modifier = Modifier.clickable { onNavigateToClasses() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(programs) { prog ->
                        Box(
                            modifier = Modifier
                                .width(200.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(GymDarkCard)
                                .border(1.dp, GymBorder, RoundedCornerShape(16.dp))
                                .clickable { onNavigateToClasses() }
                                .padding(16.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(prog.accentColor.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = prog.icon,
                                            contentDescription = null,
                                            tint = prog.accentColor,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(GymDarkSurfaceElevated)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = prog.intensity,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = GymTextSecondary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = prog.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymTextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = prog.subtitle,
                                    fontSize = 12.sp,
                                    color = GymTextSecondary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Popular Classes Today
        item {
            Column(modifier = Modifier.padding(top = 22.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TODAY'S SCHEDULE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Text(
                            text = "Trending Studio Classes",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                    }
                    Text(
                        text = "Full Schedule",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymOrangePrimary,
                        modifier = Modifier.clickable { onNavigateToClasses() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    classes.take(3).forEach { gymClass ->
                        HomeClassItemCard(
                            gymClass = gymClass,
                            onBookClick = { onBookClassClick(gymClass) }
                        )
                    }
                }
            }
        }

        // Section: Facilities Highlight
        item {
            Column(modifier = Modifier.padding(top = 22.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PREMIUM AMENITIES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Text(
                            text = "World-Class Fitness Spaces",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                    }
                    Text(
                        text = "Explore Club",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymOrangePrimary,
                        modifier = Modifier.clickable { onNavigateToFacilities() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(facilities.take(3)) { fac ->
                        Box(
                            modifier = Modifier
                                .width(220.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(GymDarkCard)
                                .border(1.dp, GymBorder, RoundedCornerShape(16.dp))
                                .clickable { onNavigateToFacilities() }
                                .padding(16.dp)
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(GymOrangePrimary.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = fac.category.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GymOrangePrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = fac.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymTextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = fac.openingHours,
                                    fontSize = 11.sp,
                                    color = GymNeonAccent
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${fac.equipmentCount} Stations & Zones",
                                    fontSize = 11.sp,
                                    color = GymTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(GymDarkCard)
            .border(1.dp, GymBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = GymTextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = GymTextSecondary
            )
        }
    }
}

@Composable
fun HomeClassItemCard(
    gymClass: GymClassEntity,
    onBookClick: () -> Unit
) {
    val spotsLeft = (gymClass.capacity - gymClass.bookedCount).coerceAtLeast(0)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(GymDarkCard)
            .border(1.dp, GymBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(GymOrangePrimary.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = gymClass.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymOrangePrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${gymClass.dayOfWeek} • ${gymClass.timeSlot}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = GymTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = gymClass.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GymTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = GymTextSecondary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = gymClass.trainerName,
                    fontSize = 11.sp,
                    color = GymTextSecondary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "•",
                    fontSize = 11.sp,
                    color = GymTextSecondary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$spotsLeft spots left",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (spotsLeft <= 3) GymOrangePrimary else GymNeonAccent
                )
            }
        }

        Button(
            onClick = onBookClick,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = GymOrangePrimary,
                contentColor = Color.White
            ),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            modifier = Modifier.height(36.dp)
        ) {
            Text("Book", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
