package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.RoomService
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GymFacilityEntity
import com.example.data.model.TrainerEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymGold
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary

@Composable
fun TrainersFacilitiesScreen(
    trainers: List<TrainerEntity>,
    facilities: List<GymFacilityEntity>,
    onTrainerConsultationClick: (TrainerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Trainers, 1: Facilities

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GymDarkBackground)
    ) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = GymDarkSurface,
            contentColor = GymOrangePrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = GymOrangePrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Text(
                        "Elite Coaches (${trainers.size})",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 0) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text(
                        "Facilities & Zones (${facilities.size})",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 1) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
        }

        if (selectedTab == 0) {
            // Trainers Directory
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                item {
                    Column {
                        Text(
                            text = "CERTIFIED PERSONAL COACHES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Train With Champions",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = GymTextPrimary
                            )
                        )
                        Text(
                            text = "World-class credentials, customized periodization, and form coaching.",
                            fontSize = 12.sp,
                            color = GymTextSecondary
                        )
                    }
                }

                items(trainers, key = { it.id }) { trainer ->
                    TrainerCard(
                        trainer = trainer,
                        onConsultClick = { onTrainerConsultationClick(trainer) }
                    )
                }
            }
        } else {
            // Gym Facilities Directory
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                item {
                    Column {
                        Text(
                            text = "PREMIUM ATHLETIC AMENITIES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "State-Of-The-Art Equipment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = GymTextPrimary
                            )
                        )
                        Text(
                            text = "Every facility is cleaned daily with hospital-grade sanitization.",
                            fontSize = 12.sp,
                            color = GymTextSecondary
                        )
                    }
                }

                items(facilities, key = { it.id }) { facility ->
                    FacilityCard(facility = facility)
                }
            }
        }
    }
}

@Composable
fun TrainerCard(
    trainer: TrainerEntity,
    onConsultClick: () -> Unit
) {
    val initials = trainer.name.split(" ")
        .mapNotNull { it.firstOrNull()?.toString() }
        .take(2)
        .joinToString("")

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = GymDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("trainer_card_${trainer.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(GymDarkSurfaceElevated)
                            .border(1.5.dp, GymOrangePrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymOrangePrimary
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = trainer.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                        Text(
                            text = trainer.specialty,
                            fontSize = 12.sp,
                            color = GymOrangePrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GymDarkSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = GymGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${trainer.rating} (${trainer.reviewsCount})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = trainer.bio,
                fontSize = 12.sp,
                color = GymTextSecondary,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Certifications & Experience Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(GymDarkSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = GymGold, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(trainer.certifications, fontSize = 10.sp, color = GymTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccessTime, null, tint = GymNeonAccent, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Hours: ${trainer.availability}", fontSize = 11.sp, color = GymNeonAccent)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onConsultClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GymOrangePrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("book_coach_button_${trainer.id}")
            ) {
                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Request 1-on-1 Consultation", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun FacilityCard(
    facility: GymFacilityEntity
) {
    val icon = when (facility.category) {
        "Strength" -> Icons.Default.FitnessCenter
        "Recovery" -> Icons.Default.Spa
        "Aquatics" -> Icons.Default.Pool
        "Nutrition" -> Icons.Default.RoomService
        else -> Icons.Default.FitnessCenter
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = GymDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GymOrangePrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, null, tint = GymOrangePrimary, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = facility.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                        Text(
                            text = facility.category.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymOrangePrimary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(GymDarkSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${facility.equipmentCount} Stations",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GymTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = facility.description,
                fontSize = 12.sp,
                color = GymTextSecondary,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccessTime, null, tint = GymNeonAccent, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Schedule: ${facility.openingHours}", fontSize = 11.sp, color = GymNeonAccent)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Key Highlights: ${facility.highlights}",
                fontSize = 11.sp,
                color = GymTextSecondary.copy(alpha = 0.8f)
            )
        }
    }
}
