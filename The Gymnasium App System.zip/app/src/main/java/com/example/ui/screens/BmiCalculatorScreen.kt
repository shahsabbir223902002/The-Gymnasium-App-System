package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BmiRecordEntity
import com.example.ui.theme.GymAmberSecondary
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymRedAccent
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BmiCalculatorScreen(
    heightCm: Float,
    weightKg: Float,
    gender: String,
    age: Int,
    bmiRecords: List<BmiRecordEntity>,
    onHeightChange: (Float) -> Unit,
    onWeightChange: (Float) -> Unit,
    onGenderChange: (String) -> Unit,
    onAgeChange: (Int) -> Unit,
    onSaveBmiRecord: (category: String, recommendation: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val heightM = heightCm / 100f
    val bmi = (weightKg / (heightM * heightM)).coerceIn(10f, 50f)

    val (category, categoryColor, recommendation, workoutPlan) = when {
        bmi < 18.5f -> Quadruple(
            "Underweight",
            GymAmberSecondary,
            "Caloric surplus recommended with progressive hypertrophy training to build lean muscle mass.",
            "3x Weekly Full Body Strength + 3000 kcal Diet"
        )
        bmi in 18.5f..24.9f -> Quadruple(
            "Normal Healthy Weight",
            GymNeonAccent,
            "Optimal body composition. Continue consistent strength maintenance and cardiovascular conditioning.",
            "4x Weekly Push/Pull/Legs + 2x HIIT Sessions"
        )
        bmi in 25.0f..29.9f -> Quadruple(
            "Overweight",
            GymOrangePrimary,
            "Moderate caloric deficit paired with high intensity metabolic resistance circuits recommended.",
            "Inferno HIIT + Heavy Compound Weightlifting"
        )
        else -> Quadruple(
            "Obese",
            GymRedAccent,
            "Structured cardiovascular endurance, low impact joint-friendly workouts, and macro-tracking advised.",
            "Low-Impact Cycling, Rowing & Caloric Deficit"
        )
    }

    // Daily Calorie Maintenance estimate using Mifflin-St Jeor Formula
    val bmr = if (gender == "Male") {
        (10 * weightKg) + (6.25f * heightCm) - (5 * age) + 5
    } else {
        (10 * weightKg) + (6.25f * heightCm) - (5 * age) - 161
    }
    val maintenanceCalories = (bmr * 1.55f).toInt() // Moderately active gym-goer
    val waterIntakeLiters = (weightKg * 0.035f)

    val idealWeightMin = 18.5f * (heightM * heightM)
    val idealWeightMax = 24.9f * (heightM * heightM)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GymDarkBackground),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title & Header
        item {
            Column {
                Text(
                    text = "BIOMETRIC ANALYSIS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = GymOrangePrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "BMI & Fitness Calculator",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = GymTextPrimary
                    )
                )
                Text(
                    text = "Calculate Body Mass Index, target ranges, and personalized gym routines.",
                    fontSize = 12.sp,
                    color = GymTextSecondary
                )
            }
        }

        // Animated Visual Gauge & Result Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(categoryColor.copy(alpha = 0.5f))),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bmi_result_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    BmiArcGauge(
                        bmi = bmi,
                        categoryColor = categoryColor,
                        modifier = Modifier.size(220.dp, 130.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "%.1f".format(bmi),
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        color = categoryColor
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(categoryColor.copy(alpha = 0.15f))
                            .border(1.dp, categoryColor, RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = category.uppercase(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = categoryColor,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = recommendation,
                        fontSize = 12.sp,
                        color = GymTextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Key Stats Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BmiStatItem(
                            icon = Icons.Default.MonitorWeight,
                            label = "Ideal Weight",
                            value = "${"%.1f".format(idealWeightMin)}-${"%.1f".format(idealWeightMax)} kg",
                            modifier = Modifier.weight(1f)
                        )
                        BmiStatItem(
                            icon = Icons.Default.LocalFireDepartment,
                            label = "Calories / Day",
                            value = "$maintenanceCalories kcal",
                            modifier = Modifier.weight(1f)
                        )
                        BmiStatItem(
                            icon = Icons.Default.LocalDrink,
                            label = "Hydration",
                            value = "${"%.1f".format(waterIntakeLiters)} L",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tailored Workout Plan Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(GymDarkSurfaceElevated)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FitnessCenter,
                            contentDescription = null,
                            tint = GymOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "RECOMMENDED GYM ROUTINE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GymOrangePrimary
                            )
                            Text(
                                text = workoutPlan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = GymTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onSaveBmiRecord(category, recommendation) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GymOrangePrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_bmi_button")
                    ) {
                        Icon(imageVector = Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Assessment to Fitness Log", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Interactive Sliders & Controls Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Adjust Body Metrics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GymTextPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Gender Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("Male", "Female").forEach { g ->
                            val isSelected = gender == g
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) GymOrangePrimary.copy(alpha = 0.2f) else GymDarkSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (isSelected) GymOrangePrimary else GymBorder,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onGenderChange(g) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = g,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) GymOrangePrimary else GymTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Height Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Height", fontSize = 13.sp, color = GymTextSecondary)
                        Text(
                            "${heightCm.toInt()} cm",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GymOrangePrimary
                        )
                    }
                    Slider(
                        value = heightCm,
                        onValueChange = onHeightChange,
                        valueRange = 120f..220f,
                        colors = SliderDefaults.colors(
                            thumbColor = GymOrangePrimary,
                            activeTrackColor = GymOrangePrimary,
                            inactiveTrackColor = GymDarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("height_slider")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Weight Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Weight", fontSize = 13.sp, color = GymTextSecondary)
                        Text(
                            "${"%.1f".format(weightKg)} kg",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GymOrangePrimary
                        )
                    }
                    Slider(
                        value = weightKg,
                        onValueChange = onWeightChange,
                        valueRange = 40f..160f,
                        colors = SliderDefaults.colors(
                            thumbColor = GymOrangePrimary,
                            activeTrackColor = GymOrangePrimary,
                            inactiveTrackColor = GymDarkSurfaceElevated
                        ),
                        modifier = Modifier.testTag("weight_slider")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Age Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Age", fontSize = 13.sp, color = GymTextSecondary)
                        Text(
                            "$age years",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GymOrangePrimary
                        )
                    }
                    Slider(
                        value = age.toFloat(),
                        onValueChange = { onAgeChange(it.toInt()) },
                        valueRange = 14f..80f,
                        colors = SliderDefaults.colors(
                            thumbColor = GymOrangePrimary,
                            activeTrackColor = GymOrangePrimary,
                            inactiveTrackColor = GymDarkSurfaceElevated
                        )
                    )
                }
            }
        }

        // Section: History of BMI Logs
        if (bmiRecords.isNotEmpty()) {
            item {
                Text(
                    text = "Past BMI Log Entries",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = GymTextPrimary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(bmiRecords, key = { it.id }) { record ->
                val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(record.timestamp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = record.category,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GymTextPrimary
                            )
                            Text(
                                text = "${record.heightCm.toInt()} cm • ${record.weightKg.toInt()} kg • $dateStr",
                                fontSize = 11.sp,
                                color = GymTextSecondary
                            )
                        }

                        Text(
                            text = "%.1f".format(record.bmi),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = GymOrangePrimary
                        )
                    }
                }
            }
        }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun BmiArcGauge(
    bmi: Float,
    categoryColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedBmi by animateFloatAsState(
        targetValue = bmi,
        animationSpec = tween(durationMillis = 600),
        label = "bmi_arc"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val radius = (w / 2f) - 20f
        val center = Offset(w / 2f, h - 10f)

        val strokeWidth = 14.dp.toPx()

        // Background track (180 degrees arc)
        drawArc(
            color = Color(0xFF222530),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )

        // Active Arc calculated from BMI (range 15 to 40)
        val normalized = ((animatedBmi - 15f) / (40f - 15f)).coerceIn(0f, 1f)
        val sweep = normalized * 180f

        drawArc(
            color = categoryColor,
            startAngle = 180f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )

        // Needle indicator
        val angleRad = Math.toRadians((180f + sweep).toDouble())
        val needleLen = radius - 15f
        val endX = center.x + (needleLen * cos(angleRad)).toFloat()
        val endY = center.y + (needleLen * sin(angleRad)).toFloat()

        drawLine(
            color = Color.White,
            start = center,
            end = Offset(endX, endY),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Center needle pivot
        drawCircle(
            color = categoryColor,
            radius = 6.dp.toPx(),
            center = center
        )
    }
}

@Composable
fun BmiStatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(GymDarkSurfaceElevated)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = GymOrangePrimary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 10.sp, color = GymTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GymTextPrimary)
    }
}
