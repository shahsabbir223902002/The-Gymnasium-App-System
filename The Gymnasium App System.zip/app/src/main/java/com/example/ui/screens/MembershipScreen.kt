package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MembershipPlanEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.UserEntity
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkCard
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymGold
import com.example.ui.theme.GymNeonAccent
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MembershipScreen(
    user: UserEntity?,
    plans: List<MembershipPlanEntity>,
    payments: List<PaymentEntity>,
    onSelectPlan: (MembershipPlanEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Plans, 1: Payment History

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GymDarkBackground)
    ) {
        // Tab Selector
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = GymDarkSurface,
            contentColor = GymOrangePrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = GymOrangePrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Text(
                        "Membership Tiers",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 0) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text(
                        "Payment History (${payments.size})",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 1) GymOrangePrimary else GymTextSecondary
                    )
                }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                item {
                    Column {
                        Text(
                            text = "FLEXIBLE CLUB MEMBERSHIPS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = GymOrangePrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Choose Your Training Pass",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = GymTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No long-term commitments. Upgrade, pause, or switch plans at any time with instant access.",
                            fontSize = 12.sp,
                            color = GymTextSecondary
                        )
                    }
                }

                items(plans, key = { it.id }) { plan ->
                    val isCurrentPlan = user?.membershipTier?.equals(plan.id, ignoreCase = true) == true
                    MembershipPlanCard(
                        plan = plan,
                        isCurrentPlan = isCurrentPlan,
                        onSelectPlan = { onSelectPlan(plan) }
                    )
                }
            }
        } else {
            // Payment History & Invoices Tab
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                item {
                    Text(
                        text = "Transactions & Official Invoices",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GymTextPrimary
                        )
                    )
                    Text(
                        text = "All online payments and membership subscriptions recorded securely.",
                        fontSize = 12.sp,
                        color = GymTextSecondary
                    )
                }

                if (payments.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = GymTextSecondary.copy(alpha = 0.5f),
                                    modifier = Modifier.size(54.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "No payment history yet",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GymTextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Invoices and transaction receipts will be logged here.",
                                    fontSize = 12.sp,
                                    color = GymTextSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(payments, key = { it.id }) { payment ->
                        val dateFormatted = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
                            .format(Date(payment.timestamp))

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = GymDarkCard),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GymBorder)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(GymOrangePrimary.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CreditCard,
                                                contentDescription = null,
                                                tint = GymOrangePrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = payment.itemDescription,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = GymTextPrimary
                                            )
                                            Text(
                                                text = payment.invoiceNumber,
                                                fontSize = 11.sp,
                                                color = GymTextSecondary
                                            )
                                        }
                                    }

                                    Text(
                                        text = "$${"%.2f".format(payment.amount)}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Black,
                                        color = GymOrangePrimary
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Method: ${payment.paymentMethod} • Tx: ${payment.transactionId}",
                                        fontSize = 11.sp,
                                        color = GymTextSecondary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(GymNeonAccent.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "PAID",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = GymNeonAccent
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = dateFormatted,
                                    fontSize = 10.sp,
                                    color = GymTextSecondary.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MembershipPlanCard(
    plan: MembershipPlanEntity,
    isCurrentPlan: Boolean,
    onSelectPlan: () -> Unit
) {
    val perks = plan.perksList.split(",").filter { it.isNotBlank() }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (plan.isPopular) GymDarkSurfaceElevated else GymDarkCard
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                when {
                    isCurrentPlan -> GymNeonAccent
                    plan.isPopular -> GymOrangePrimary
                    else -> GymBorder
                }
            )
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("plan_card_${plan.id}")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Header Row (Badge / Active Status)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when {
                                isCurrentPlan -> GymNeonAccent.copy(alpha = 0.2f)
                                plan.isPopular -> GymOrangePrimary.copy(alpha = 0.2f)
                                else -> GymDarkSurface
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isCurrentPlan) "CURRENT ACTIVE PASS" else plan.badge,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        color = when {
                            isCurrentPlan -> GymNeonAccent
                            plan.isPopular -> GymOrangePrimary
                            else -> GymTextSecondary
                        }
                    )
                }

                if (plan.isPopular) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = GymGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "TOP CHOICE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = GymGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = plan.title,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = GymTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = plan.tagline,
                fontSize = 12.sp,
                color = GymTextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Price Row
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "$${"%.2f".format(plan.price)}",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Black,
                    color = GymOrangePrimary
                )
                Text(
                    text = if (plan.durationMonths == 12) " / year" else " / month",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GymTextSecondary,
                    modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Features Checklist
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                perks.forEach { perk ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(GymOrangePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = GymOrangePrimary,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = perk.trim(),
                            fontSize = 12.sp,
                            color = GymTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onSelectPlan,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCurrentPlan) GymDarkSurface else GymOrangePrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("select_plan_button_${plan.id}")
            ) {
                Text(
                    text = if (isCurrentPlan) "Renew Current Pass" else "Select & Proceed to Checkout",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
