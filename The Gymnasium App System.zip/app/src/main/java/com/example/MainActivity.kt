package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardMembership
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BookingDialog
import com.example.ui.components.GymTopBar
import com.example.ui.components.NotificationDialog
import com.example.ui.components.PaymentCheckoutDialog
import com.example.ui.components.PaymentSuccessDialog
import com.example.ui.components.ProfileAuthDialog
import com.example.ui.screens.BmiCalculatorScreen
import com.example.ui.screens.ClassesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MembershipScreen
import com.example.ui.screens.TrainersFacilitiesScreen
import com.example.ui.theme.GymBorder
import com.example.ui.theme.GymDarkBackground
import com.example.ui.theme.GymDarkSurface
import com.example.ui.theme.GymDarkSurfaceElevated
import com.example.ui.theme.GymOrangeDark
import com.example.ui.theme.GymOrangePrimary
import com.example.ui.theme.GymTextPrimary
import com.example.ui.theme.GymTextSecondary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GymViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                GymnasiumApp()
            }
        }
    }
}

@Composable
fun GymnasiumApp(
    viewModel: GymViewModel = viewModel()
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allPlans by viewModel.allPlans.collectAsStateWithLifecycle()
    val allClasses by viewModel.allClasses.collectAsStateWithLifecycle()
    val allTrainers by viewModel.allTrainers.collectAsStateWithLifecycle()
    val allFacilities by viewModel.allFacilities.collectAsStateWithLifecycle()
    val userBookings by viewModel.userBookings.collectAsStateWithLifecycle()
    val userPayments by viewModel.userPayments.collectAsStateWithLifecycle()
    val userBmiRecords by viewModel.userBmiRecords.collectAsStateWithLifecycle()
    val userNotifications by viewModel.userNotifications.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()

    val selectedClassForBooking by viewModel.selectedClassForBooking.collectAsStateWithLifecycle()
    val selectedPlanForPayment by viewModel.selectedPlanForPayment.collectAsStateWithLifecycle()
    val latestPaymentSuccess by viewModel.latestPaymentSuccess.collectAsStateWithLifecycle()
    val showAuthDialog by viewModel.showAuthDialog.collectAsStateWithLifecycle()
    val showNotificationDialog by viewModel.showNotificationDialog.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val heightCm by viewModel.bmiHeightCm.collectAsStateWithLifecycle()
    val weightKg by viewModel.bmiWeightKg.collectAsStateWithLifecycle()
    val gender by viewModel.bmiGender.collectAsStateWithLifecycle()
    val age by viewModel.bmiAge.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = GymDarkBackground,
        topBar = {
            GymTopBar(
                user = currentUser,
                unreadCount = unreadCount,
                onNotificationClick = { viewModel.setShowNotificationDialog(true) },
                onProfileClick = { viewModel.setShowAuthDialog(true) }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = GymDarkSurface,
                contentColor = GymOrangePrimary,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("gym_bottom_navigation")
            ) {
                val navItems = listOf(
                    NavigationItem("Home", Icons.Default.Home, Icons.Outlined.Home, "nav_home"),
                    NavigationItem("Classes", Icons.Default.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_classes"),
                    NavigationItem("Plans", Icons.Default.CardMembership, Icons.Outlined.CardMembership, "nav_plans"),
                    NavigationItem("BMI", Icons.Default.Calculate, Icons.Outlined.Calculate, "nav_bmi"),
                    NavigationItem("Club", Icons.Default.FitnessCenter, Icons.Outlined.FitnessCenter, "nav_club")
                )

                navItems.forEachIndexed { index, item ->
                    val isSelected = currentTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = index },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.label,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = GymOrangePrimary,
                            indicatorColor = GymOrangePrimary,
                            unselectedIconColor = GymTextSecondary,
                            unselectedTextColor = GymTextSecondary
                        ),
                        modifier = Modifier.testTag(item.tag)
                    )
                }
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    containerColor = GymDarkSurfaceElevated,
                    contentColor = GymTextPrimary,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                ) {
                    Text(text = data.visuals.message, fontWeight = FontWeight.Medium)
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                0 -> HomeScreen(
                    user = currentUser,
                    classes = allClasses,
                    plans = allPlans,
                    facilities = allFacilities,
                    userBookings = userBookings,
                    onNavigateToClasses = { currentTab = 1 },
                    onNavigateToPlans = { currentTab = 2 },
                    onNavigateToBmi = { currentTab = 3 },
                    onNavigateToFacilities = { currentTab = 4 },
                    onBookClassClick = { gymClass -> viewModel.selectClassForBooking(gymClass) },
                    onUpgradePlanClick = { plan -> viewModel.selectPlanForPayment(plan) }
                )
                1 -> ClassesScreen(
                    classes = allClasses,
                    bookings = userBookings,
                    onBookClass = { gymClass -> viewModel.selectClassForBooking(gymClass) },
                    onCancelBooking = { booking -> viewModel.cancelBooking(booking) }
                )
                2 -> MembershipScreen(
                    user = currentUser,
                    plans = allPlans,
                    payments = userPayments,
                    onSelectPlan = { plan -> viewModel.selectPlanForPayment(plan) }
                )
                3 -> BmiCalculatorScreen(
                    heightCm = heightCm,
                    weightKg = weightKg,
                    gender = gender,
                    age = age,
                    bmiRecords = userBmiRecords,
                    onHeightChange = { viewModel.setHeight(it) },
                    onWeightChange = { viewModel.setWeight(it) },
                    onGenderChange = { viewModel.setGender(it) },
                    onAgeChange = { viewModel.setAge(it) },
                    onSaveBmiRecord = { cat, rec -> viewModel.saveCurrentBmiCalculation(cat, rec) }
                )
                4 -> TrainersFacilitiesScreen(
                    trainers = allTrainers,
                    facilities = allFacilities,
                    onTrainerConsultationClick = { trainer ->
                        viewModel.selectClassForBooking(
                            allClasses.firstOrNull { it.trainerName == trainer.name }
                        )
                    }
                )
            }
        }

        // Booking Modal Dialog
        selectedClassForBooking?.let { gymClass ->
            BookingDialog(
                gymClass = gymClass,
                onDismiss = { viewModel.selectClassForBooking(null) },
                onConfirmBooking = { dateStr ->
                    viewModel.bookClass(gymClass, dateStr)
                }
            )
        }

        // Payment Checkout Dialog
        selectedPlanForPayment?.let { plan ->
            PaymentCheckoutDialog(
                plan = plan,
                onDismiss = { viewModel.selectPlanForPayment(null) },
                onPaymentSuccess = { method ->
                    viewModel.executePlanPayment(plan, method)
                }
            )
        }

        // Payment Success Receipt Dialog
        latestPaymentSuccess?.let { payment ->
            PaymentSuccessDialog(
                payment = payment,
                onDismiss = { viewModel.dismissPaymentSuccess() }
            )
        }

        // In-app Notification Dialog
        if (showNotificationDialog) {
            NotificationDialog(
                notifications = userNotifications,
                onDismiss = { viewModel.setShowNotificationDialog(false) },
                onMarkAllRead = { viewModel.markNotificationsRead() },
                onDeleteNotification = { id -> viewModel.deleteNotification(id) }
            )
        }

        // User Profile & Authentication Dialog
        if (showAuthDialog) {
            ProfileAuthDialog(
                user = currentUser,
                onDismiss = { viewModel.setShowAuthDialog(false) },
                onLogin = { email -> viewModel.login(email) },
                onRegister = { name, email, phone, goal ->
                    viewModel.register(name, email, phone, goal)
                },
                onUpdateProfile = { name, phone, goal ->
                    viewModel.updateProfile(name, phone, goal)
                }
            )
        }
    }
}

data class NavigationItem(
    val label: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val tag: String
)

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Gymnasium: $name", modifier = modifier, color = GymOrangePrimary)
}
